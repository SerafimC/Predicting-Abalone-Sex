import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from data_prep import X_train, X_test, y_train, y_test, target_names

clf = SVC(decision_function_shape= 'ovr',
			gamma='auto', 
			tol=1e-10,
			class_weight='balanced', 
			kernel='rbf', 
			random_state=0,
			verbose=False,
			probability=True,
			C=1000)

clf.fit(X_train, y_train)

y_hat = clf.predict(X_test)

print(metrics.classification_report(y_test, y_hat, target_names=target_names))
print('Acerto: ' + str(np.mean(y_hat == y_test)*100) + '%') 