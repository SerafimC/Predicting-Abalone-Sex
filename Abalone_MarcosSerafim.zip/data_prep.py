import numpy as np
from sklearn.model_selection import train_test_split
from sklearn import preprocessing

abalone = np.genfromtxt('abalone.data', delimiter=',', dtype='str')

#labels
targets = abalone[:, 0]

le = preprocessing.LabelEncoder()
le.fit(targets)

targets = le.transform(targets)

# Remove labels
abalone = np.delete(abalone, 0, axis=1)

# convert to float all data
abalone = list(map(lambda x: [float(s) for s in x], abalone))
abalone = np.asarray(abalone)

# Features
features = abalone[:, :-3]

X_train, X_test, y_train, y_test = train_test_split(features, targets, test_size = 0.3, random_state=0)

target_names = np.array(['F', 'I', 'M'])
feature_names = np.array(['len', 'diameter', 'height', 'Whole weight',
                'Shucked weight', 'Viscera weight',
                'Shell weight', 'Rings'])